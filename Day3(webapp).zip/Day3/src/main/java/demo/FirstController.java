package demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller
@RestController //=Controller+ ResponseBody
@RequestMapping(value = "/first")
public class FirstController {
	@GetMapping
	//@ResponseBody
	public String method1() {
		String str = "<h1>Method1 invoked GET</h1>";
		System.out.println(str);
		//return "/index.html";
		return str;
	}
	@PostMapping
	public String method2() {
		String str = "<h1>Method2 invoked POST</h1>";
		System.out.println(str);
		//return "/index.html";
		return str;
	}
	
	@PutMapping
	public String method3() {
		String str = "<h1>Method3 invoked PUT</h1>";
		System.out.println(str);
		//return "/index.html";
		return str;
	}
	
	@DeleteMapping
	public String method4() {
		String str = "<h1>Method4 invoked DELETE</h1>";
		System.out.println(str);
		//return "/index.html";
		return str;
	}
	
	
}
