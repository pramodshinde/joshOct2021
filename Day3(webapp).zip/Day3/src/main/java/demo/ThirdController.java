package demo;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller
@RestController //=Controller+ ResponseBody
@RequestMapping(value = "/third")
public class ThirdController {
	@GetMapping(value="/{nm}")
	public String meth1(@PathVariable(name = "nm")String name) {
		String str = "Hello, " + name;
		System.out.println(str);
		return str;
	}
	@GetMapping(value="/rp")
	public String meth2(@RequestParam(name = "nm")String name) {
		String str = "Hello in RP, " + name;
		System.out.println(str);
		return str;
	}
	
	
	@GetMapping(produces = MediaType.TEXT_PLAIN_VALUE)
	public String method1() {
		String str = "Plain Text";
		System.out.println(str);
		//return "/index.html";
		return str;
	}
	@GetMapping(produces = MediaType.TEXT_HTML_VALUE)
	public String method2() {
		String str = "<h1>html invoked GET</h1>";
		System.out.println(str);
		return str;
	}
	@GetMapping(produces = MediaType.APPLICATION_XML_VALUE)
	public String method3() {
		String str = "<notes><note><from>aa</from></note></notes>";
		System.out.println(str);
		return str;
	}
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public String method4() {
		String str = "{\"name\" : \"aa\"}";
		System.out.println(str);
		return str;
	}
	
	
}
