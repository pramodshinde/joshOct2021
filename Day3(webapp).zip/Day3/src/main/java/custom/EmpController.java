package custom;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pojos.Emp;
@RestController
@RequestMapping(value="/emp")
public class EmpController {

	private List<Emp> list =new ArrayList<Emp>();
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public String insert(@RequestBody Emp e) {
		System.out.println("in insert of EmpController with " + e);
		list.add(e);
		return "success";
	}
@GetMapping (produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Emp> list(){
		System.out.println("in List " + list.size());
		return list;
	}
}
