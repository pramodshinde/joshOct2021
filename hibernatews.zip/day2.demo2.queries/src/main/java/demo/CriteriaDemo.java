package demo;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

import util.HibernateUtil;

public class CriteriaDemo {

	private static SessionFactory factory = HibernateUtil.getFactory();

	public static void q1() {
		Session session = null;
		try {
			session = factory.openSession();
			Criteria q = session.createCriteria(Employee.class);
			List<Employee> list = q.list();
			for (Employee employee : list) {
				System.out.println(employee);
			}
		} finally {
			session.close();
		}
	}

	public static void q2() {
		Session session = null;
		try {
			session = factory.openSession();
			Criteria q = session.createCriteria(Employee.class);
			ScrollableResults results = q.scroll();
			while(results.next())
			{
				System.out.println(results.get(0));
				
			}
		} finally {
			session.close();
		}
	}

	
	public static void q3() {
		Session session = null;
		try {
			session = factory.openSession();
			Criteria q = session.createCriteria(Employee.class);
			q.add(Restrictions.eq("city" ,"Hyd"));
			List<Employee> list = q.list();
			for (Employee employee : list) {
				System.out.println(employee);
			}
		} finally {
			session.close();
		}
	}
	public static void main(String[] args) {
		q1();
		q2();
		q3();
	}

}
