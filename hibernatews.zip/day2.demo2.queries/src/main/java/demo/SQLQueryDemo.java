package demo;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import util.HibernateUtil;

public class SQLQueryDemo {

	private static SessionFactory factory = HibernateUtil.getFactory();

	public static void q1() {
		Session session = null;
		try {
			session = factory.openSession();
			// sql - Include table name and column names
	//		SQLQuery<Employee> query = session.createSQLQuery("select * from Employee");
			NativeQuery<Employee> query = session.createNativeQuery("select * from Employee",Employee.class);
			List<Employee> list = query.getResultList();
			for (Employee employee : list) {
				System.out.println(employee);
			}
		} finally {
			session.close();
		}
	}
	public static void main(String[] args) {
		q1();
	}

}
