package demo;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;

import org.hibernate.query.Query;

import util.HibernateUtil;

public class QueryDemo {

	private static SessionFactory factory = HibernateUtil.getFactory();

	public static void q1() {
		Session session = null;
		try {
			session = factory.openSession();
			Query q = session.createQuery("select e from Employee e");
			List<Employee> list = q.getResultList();
			for (Employee employee : list) {
				System.out.println(employee);
			}
		} finally {
			session.close();
		}
	}

	public static void q2() {
		Session session = null;
		try {
			session = factory.openSession();
			Query q = session.createQuery("select e.empno, e.ename, e.city  from Employee e");
			ScrollableResults results = q.scroll();
			while(results.next())
			{
				System.out.println(results.get(0) + "\t\t" + results.get(1) +"\t\t" + results.get(2));
				
			}
		} finally {
			session.close();
		}
	}

	public static void q3() {
		Session session = null;
		try {
			session = factory.openSession();
			Query q = session.createQuery("select e  from Employee e");
			Iterator<Employee> iterator = q.iterate();
			while(iterator.hasNext())
			{
				System.out.println(iterator.next());
			}
		} finally {
			session.close();
		}
	}
	public static void q4() {
		Session session = null;
		try {
			session = factory.openSession();
			Query q = session.getNamedQuery("myq");
			q.setString("city", "Hyd");
			List<Employee> list = q.getResultList();
			for (Employee employee : list) {
				System.out.println(employee);
			}
		} finally {
			session.close();
		}
	}
	public static void main(String[] args) {
		//q1();
		q4();
	}

}
