package demo;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import util.HibernateUtil;

public class ManageEmployee {

	private static SessionFactory factory = HibernateUtil.getFactory();

	public static void main(String[] args) {

		ManageEmployee mgr = new ManageEmployee();
		for(int i = 1; i <= 100;i+=1)
		{
			Employee e = new Employee();
			e.setEmpno(i);
			e.setEname(" name" + i);
			e.setSalary(i*1000);
			if( (i % 2)==0)
				e.setCity("Hyd" );
			else
				e.setCity("Blr");
			e.setBdate(new Date());
			mgr.add(e);
		}
		HibernateUtil.close();

	}

	


	public void add(Employee e) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(e);
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}

	}

}
