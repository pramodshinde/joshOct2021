package demo;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;

import org.hibernate.query.Query;
import org.hibernate.stat.Statistics;

import util.HibernateUtil;

public class QueryDemo {

	private static SessionFactory factory = HibernateUtil.getFactory();
public static void printstats()
{
	Statistics stats = factory.getStatistics();
	System.out.println("Opened Sessions = " + stats.getSessionOpenCount());	
	System.out.println("Closed  Sessions = " + stats.getSessionCloseCount());
	System.out.println("Slowest query  = " + stats.getQueryExecutionMaxTimeQueryString());
	System.out.println("Max times query " + stats.getQueryExecutionCount());
	String[] queries = stats.getQueries();
	for (int i = 0; i < queries.length; i++) {
		String s= queries[i];
		System.out.println(i + " \t\t " + s + "\t\t" + stats.getQueryStatistics(s));
	}
}
	public static void q1(Session session ) {
		//Session session = null;
		try {
		//	session = factory.getCurrentSession();
			Query q = session.createQuery("select e from Employee e");
			List<Employee> list = q.getResultList();
			System.out.println(" After list - Number of records = " + list.size());
		} finally {
		//	session.close();
		}
	}

	public static void q2(String cityname) {
		Session session = null;
		try {
			session = factory.getCurrentSession();
			Query q = session.getNamedQuery("myq");
			q.setString("city", cityname);
			List<Employee> list = q.getResultList();
			System.out.println(" After list - Number of records = " + list.size());
		} finally {
			//session.close();
		}
	}
	public static void main(String[] args) {
		Date st = new Date();
		Session s = factory.openSession();
		for(int i = 0; i< 100; i++)
		{
		q1(s);
		}
		s.close();
		Date et = new Date();
		System.out.println(" Time Taken for Execution " + (et.getTime() - st.getTime()));
		printstats();
	}

}
