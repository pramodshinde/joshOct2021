package demo;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.stat.Statistics;

import util.HibernateUtil;

public class CacheDemo1 {
	private static SessionFactory factory = HibernateUtil.getFactory();
	public static void printstats()
{
		Statistics stats = factory.getStatistics();
		System.out.println("Hit Count  =" + stats.getSecondLevelCacheHitCount());
		System.out.println("Miss Count  =" + stats.getSecondLevelCacheMissCount());
		System.out.println("Put Count = " + stats.getSecondLevelCachePutCount());
}
	public static void list() {
		Session session =factory.openSession();
		Query<Share> query = session.createQuery("select s from Share s",Share.class);
		query.setCacheable(true);
		List<Share> list = query.getResultList();
		System.out.println("--------------------------------List 1 ------------------------------------");
		for (Share share : list) {
			System.out.println(share);
		}
		printstats();
		//add(true);
		Query<Share> query1 = session.createQuery("select s from Share s",Share.class);
		query1.setCacheable(true);
		
		List<Share> list1 = query1.getResultList();
		System.out.println("--------------------------------List 2 ------------------------------------");
		for (Share share : list1) {
			System.out.println(share);
		}
		
		
		session.close();
	}
	public static void add(boolean in) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			if(in ==true)
			{	
				session.save(new Share("B121M","Bld",1700));
				System.out.println(" actual insert ");
			}
			System.out.println(" before commit....");
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}
	}	
	public static void main(String[] args) {
		
		//add();
		list();
		printstats();
		list();
		printstats();
		list();
		printstats();
		factory.close();
	}

}
