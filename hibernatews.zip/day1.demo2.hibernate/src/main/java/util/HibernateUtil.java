package util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.service.spi.Stoppable;

public class HibernateUtil {
	
	private HibernateUtil(){}
	public static SessionFactory getFactory() {
		return factory;
	}

	private static SessionFactory factory;
	static{
		try{
			factory = new Configuration().configure().buildSessionFactory();
			}
			catch(Exception excp){
				System.out.println("Exception in Manage Employee : "+excp.getMessage());
			}
	}
	
	public static void close()
	{
		
		factory.close();
	}
}
