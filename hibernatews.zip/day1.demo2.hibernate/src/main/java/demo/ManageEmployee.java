package demo;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import util.HibernateUtil;

public class ManageEmployee {

	private static SessionFactory factory = HibernateUtil.getFactory();

	public static void main(String[] args) {

		ManageEmployee manageEmp = new ManageEmployee();
		ManageEmployee mgr = new ManageEmployee();
		for (int i = 1; i < 100; i += 1) {
			Employee e = new Employee();
			e.setEmpno(i);
			e.setEname(" name" + i);
			e.setSalary(i * 1000);
			mgr.addEmployee(e);
		}
		mgr.list();
		HibernateUtil.close();

	}

	private void deleteEmployee(Integer id) {
		Session session = factory.openSession();
		Transaction transaction = null;

		try {
			transaction = session.beginTransaction();
			Employee employee = session.get(Employee.class, id);
			session.delete(employee);
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in updateEmployee method " + excp.getMessage());
		} finally {
			session.close();
		}

	}

	private void updateEmployee(Integer id, int salary) {

		Session session = factory.openSession();
		Transaction transaction = null;

		try {
			transaction = session.beginTransaction();
			Employee employee = session.get(Employee.class, id);
			System.out.println("employee = " + employee);
			// any other option?

			// session.update(employee);
			System.out.println("after get, before commit ");
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in updateEmployee method " + excp.getMessage());
		} finally {
			session.close();
		}

	}

	private void list() {
		Session session = factory.openSession();
	
		try {
			List<Employee> employees = session.createQuery("select e FROM Employee e").list();

			for (Employee employee : employees) {
				employee.setSalary(11);
				System.out.println(employee);
			}
		
		} catch (Exception excp) {
			System.out.println("Exception in ListEmployees Method" + excp.getMessage());
		} finally {
			session.close();
		}

	}

	public Integer addEmployee(Employee e) {
		Session session = null;
		Transaction transaction = null;
		Integer empId = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(e); // e becomes - attached object
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}

		return empId;

	}

}
