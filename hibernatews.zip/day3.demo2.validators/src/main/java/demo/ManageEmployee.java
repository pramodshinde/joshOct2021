package demo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import util.HibernateUtil;

public class ManageEmployee {

	private static SessionFactory factory = HibernateUtil.getFactory();

	public static boolean valid(Employee e) {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Employee>> set = validator.validate(e);

		if (set.size() < 0)
			return true;
		Iterator<ConstraintViolation<Employee>> itc = set.iterator();
		while (itc.hasNext()) {
			System.out.println(itc.next());
		}
		return false;
	}

	public static void main(String[] args) throws Exception {

		ManageEmployee mgr = new ManageEmployee();
		Employee e = new Employee();
		e.setEmpno("ABC-0000");
		e.setEname("AAAAAAA");
		e.setSalary(444.44);
		// e.setCity("");
		Date d = new SimpleDateFormat("MM/DD/YYYY").parse("10/20/2014");
		e.setBdate(d);
		e.setWorkemail("a@a");
		if (valid(e))
			mgr.add(e);
		HibernateUtil.close();

	}

	public void add(Employee e) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(e);
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}

	}

}
