package demo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;




import org.hibernate.validator.constraints.Email;

@Entity
@Table(name="employee")
@NamedQuery(name="myq", query="select e from Employee e where e.city = :city")
public class Employee {
	@Id
	@Column(name="empid")
	@Pattern(regexp="^[A-Z]{3}-[0-9]{4}",message= "Invalid Employeenumber")
	private String empno;
	@Column(name="ename", length=10)
	@Size(max=10,min=5,message="Invalid Ename, lenght must be between  5 and 10")
	private String ename;
	@DecimalMin(message="Invalid Salary", value="2")
	private double salary;
	@NotNull(message="City must be notnull")
	private String city;
	@Past
	private Date bdate;
	@Email(message="Invalid Email")
	
	private String workemail;
	public String getEmpno() {
		return empno;
	}
	public void setEmpno(String empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Date getBdate() {
		return bdate;
	}
	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}
	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", ename=" + ename + ", salary=" + salary + ", city=" + city + ", bdate="
				+ bdate + "]";
	}
	public String getWorkemail() {
		return workemail;
	}
	public void setWorkemail(String workemail) {
		this.workemail = workemail;
	}
	
	
		
}
