import java.util.Arrays;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import demo.Dept;
import demo.Emp;
import util.HibernateUtil;

public class OneManyClient {
	static SessionFactory sf = HibernateUtil.getFactory();

	public static void m2() {
		Session session = null;
		try {
			session = sf.openSession();
	//		Query query = session.createQuery("select d.deptno, count(e.empno) from Dept d, Emp e where d.deptno = e.department.deptno group by d.deptno");
			Query query = session.createQuery("select d from Dept d");
			List<Dept> list = query.getResultList();
			for (Dept o : list) {
				System.out.println(o);
				System.out.println("EMployees are " + o.getEmps());
			}
		} finally {
			session.close();
		}
	}
	public static void m3() {
		Session session = null;
		try {
			session = sf.openSession();
			
			TypedQuery<Dept>  query = session.createQuery("select d from Dept d",Dept.class);
			List<Dept> list = query.getResultList();
			List<Emp> emps = session.createQuery("select e from Emp e",Emp.class).getResultList();
		
			for (Emp  e :emps) {
				System.out.println(".." +e + " d = " + e.getDepartment());
			}
		} finally {
			session.close();
		}
	}

	public static void m1() {
		Session session = null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx = session.beginTransaction();
			Dept d = new Dept(40, "Prod", "Hyd");
			Emp e1 = new Emp(106, "six", 6000);
			  Emp e2 = new Emp(104,"Four",4000); 
			  Emp e3 = new 	  Emp(105,"Five",5000);

		/*	  d.getEmps().add(e1);
			  d.getEmps().add(e2);
			*/
			  session.save(d);
				
			  e1.setDepartment(d);
			  e2.setDepartment(d);
			  session.save(e1);
				 session.save(e2);
				 session.save(e3);
			 
			tx.commit();
		} catch (Exception e) {
			System.out.println(" Exceptionn " + e);
			tx.rollback();
		} finally {
			session.close();
		}
	}

	public static void main(String[] args) {
	//	m1();
		m2();
	//	m3();
		sf.close();
	}

}
