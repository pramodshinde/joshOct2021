import java.util.Arrays;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import demo.Dept;
import demo.Emp;
import util.HibernateUtil;

public class Queries {
	static SessionFactory sf = HibernateUtil.getFactory();

	
	
	public static void main(String[] args) {


		Session session = null;
		try {
			session = sf.openSession();
/*	Case - 1
 * 		List<Dept> list1 = session.createQuery("select d from Dept d").getResultList();
			Query query = session.createQuery("select e from Emp e");
			List<Emp> list = query.getResultList();
			for (Emp e : list) {
				System.out.println(e + " \t" + e.getDepartment());
			}
*/
/*			
			Query query = session.createQuery("select e, d  from Emp e, Dept d where e.department.deptno= d.deptno ");
			ScrollableResults results = query.scroll(ScrollMode.FORWARD_ONLY);
			while(results.next())
			{
				System.out.println(results.get(0).toString() + results.get(1).toString());
			}
*/			
		//	Query query = session.createQuery("select d.deptno, count(e)  from Emp e, Dept d where e.department.deptno= d.deptno group by d.deptno");
		//	Query query = session.createQuery("select d.deptno, count(e)  from  Dept as d left join d.emps  as e group by d.deptno");
			Query query = session.createQuery("select d.deptno, max(e.salary)  from Emp e, Dept d where e.department.deptno= d.deptno group by d.deptno");
			ScrollableResults results = query.scroll(ScrollMode.FORWARD_ONLY);
			while(results.next())
			{
				System.out.println(results.get(0).toString() + "\t\t"+results.get(1).toString());
			}
			
		} finally {
			session.close();
		}
		sf.close();
	}

}
