import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import demo.Dept;
import util.HibernateUtil;

public class Client {
	static SessionFactory sf = HibernateUtil.getFactory();

	public static void m2() {
		Session session = null;
		try {
			session = sf.openSession();
			TypedQuery<Dept> query = session.createQuery("select d from Dept d", Dept.class);
			query.setMaxResults(10);
			query.setFirstResult(20);
			List<Dept> list = query.getResultList();
			for (Dept dept : list) {
				System.out.println(dept);
			}
		} finally {
			session.close();
		}
	}

	public static void m1() {
		Session session = null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx = session.beginTransaction();
			for (int i = 0; i < 5; i++) {
				Dept d = new Dept();
				d.setDeptno(i);
				d.setDname("HR" + i);
				if ((i % 2) == 0)
					d.setLoc("Pune");
				else
					d.setLoc("Hyd");
				session.save(d);
				if ((i % 200) == 0) {
					session.flush();
					session.clear();
				}

			}
			tx.commit();
		} catch (Exception e) {
			System.out.println(" Exceptionn " + e);
			tx.rollback();
		} finally {
			session.close();
		}
	}

	public static void main(String[] args) {
		m1();
		m2();
		sf.close();
	}

}
