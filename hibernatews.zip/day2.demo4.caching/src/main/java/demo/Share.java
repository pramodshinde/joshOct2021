package demo;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="Shares")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)
public class Share {
	@Id
	private String sharename;
	private String category;
	private double sharerate;
	public String getSharename() {
		return sharename;
	}
	public void setSharename(String sharename) {
		this.sharename = sharename;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getSharerate() {
		return sharerate;
	}
	public void setSharerate(double sharerate) {
		this.sharerate = sharerate;
	}
	public Share(String sharename, String category, double sharerate) {
		this.sharename = sharename;
		this.category = category;
		this.sharerate = sharerate;
	}
	public Share(){}

	public String toString() {
		return "Share [sharename=" + sharename + ", category=" + category + ", sharerate=" + sharerate + "]";
	}
	
}
