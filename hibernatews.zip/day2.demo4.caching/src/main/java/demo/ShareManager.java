package demo;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class ShareManager {
	private static SessionFactory factory = HibernateUtil.getFactory();
	public static void firstleveldemo() {
		Session session =factory.openSession();
		
		List<Share> list = session.createQuery("select s from Share s",Share.class).list();
		for (Share share : list) {
			System.out.println(share);
		}
		
		Iterator<Share> it = session.createQuery("select s from Share s",Share.class).iterate();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		
		
		session.close();
	}
	public static void add() {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(new Share("IBM","IT",1000));
			session.save(new Share("HP","IT",1100));
			session.save(new Share("KP","Bld",1300));
			session.save(new Share("BrodeRidge","Fin",1400));
			session.save(new Share("CLSA","Fin",1500));
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}
	}
	public static void main(String[] args) {
		
		//add();
		firstleveldemo();
	}

}
