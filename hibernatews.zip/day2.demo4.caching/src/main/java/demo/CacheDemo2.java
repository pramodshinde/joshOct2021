package demo;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import util.HibernateUtil;

public class CacheDemo2 {
	private static SessionFactory factory = HibernateUtil.getFactory();
	public static void list(boolean in) {
		Session session =factory.openSession();
		Query<Share> query = session.createQuery("select s from Share s",Share.class);
		query.setCacheable(true);
		List<Share> list = query.getResultList();
		System.out.println("--------------------------------List 1 ------------------------------------");
		for (Share share : list) {
			System.out.println(share);
		}
	//add(in);
	//	update();
	//	delete("BM", in);
	//try {	Thread.sleep(4000);	} catch (InterruptedException e) {	e.printStackTrace();	}
		
		
		Query<Share> query1 = session.createQuery("select s from Share s",Share.class);
		query1.setCacheable(true);
		
		List<Share> list1 = query1.getResultList();
		System.out.println("--------------------------------List 2 ------------------------------------");
		for (Share share : list1) {
			System.out.println(share);
		}
		
		
		session.close();
	}
	public static void add(boolean in) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			if(in ==true)
			{	
				session.save(new Share("BM","Bld",1700));
				System.out.println(" actual insert ");
			}
			System.out.println(" before commit....");
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}
	}	
	public static void update() {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			Share s = session.get(Share.class,"KP");
			s.setSharerate(s.getSharerate()*2);
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}
	}
	public static void delete(String name,boolean in) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			
			if(in ==true)
			{
				Share s = session.get(Share.class,name);
				session.remove(s);
			}
			transaction.commit();
		} catch (Exception excp) {
			System.out.println("Exception in addEmployee Method : " + excp.getMessage());
		} finally {
			session.close();
		}
	}
	public static void main(String[] args) {
		
		//add();
		list(true);
		list(false);
		factory.close();
	}

}
