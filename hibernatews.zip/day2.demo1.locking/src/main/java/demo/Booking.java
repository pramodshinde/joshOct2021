package demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name="BookingTable")
public class Booking {
	@Id
	private String fltno;
	private int  avlTickets;
	
	/*  only for optimistic locking
	 * 
	 */
	@Version
	private int info;
	public String getFltno() {
		return fltno;
	}
	public void setFltno(String fltno) {
		this.fltno = fltno;
	}
	public int getAvlTickets() {
		return avlTickets;
	}
	public void setAvlTickets(int avlTickets) {
		this.avlTickets = avlTickets;
	}
	@Override
	public String toString() {
		return "Booking [fltno=" + fltno + ", avlTickets=" + avlTickets + "]";
	}
	
}
