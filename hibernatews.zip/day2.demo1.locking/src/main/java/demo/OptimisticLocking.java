package demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import util.HibernateUtil;
class BookTicket2 extends Thread
{
	private Session session;

	public BookTicket2(Session session) {
		this.session = session;
	}
	@Override
	public void run() {
		Transaction tx = null;
		try{
			tx = session.beginTransaction();
			Booking bk = session.get(Booking.class,"Fl1");
			System.out.println("after get = " + bk);
			bk.setAvlTickets(bk.getAvlTickets()-1);
			//Thread.sleep((long)(Math.random()*1000));
			System.out.println(" Modified bk " + bk);
			tx.commit();
			System.out.println("Commited.....");
		}catch(Exception e){
			System.out.println("Exception = " + e);
			tx.rollback();
		}finally{
			session.close();
		}
	}
}
public class OptimisticLocking  {
	private static SessionFactory sf = HibernateUtil.getFactory();
	public static void main(String[] args) throws Exception{
		for(int i =1; i< 6;i++)
		{
			BookTicket2 t1 = new BookTicket2(sf.openSession());
			t1.start();
		}
		Thread.sleep(6000);
		sf.close();
	}
}
