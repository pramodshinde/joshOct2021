package demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.plaf.synth.SynthSeparatorUI;

public class DeptManager {
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("myunit");

	public void list() {
		EntityManager em = null;
		try {
			em = emf.createEntityManager();
			Query q = em.createQuery("select d from Dept d");
			List<Dept> list = q.getResultList();
			for (Dept dept : list) {
				System.out.println(dept);
			}
		} finally {
			em.close();
		}
	}

	public void delete(int deptno) {
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			Dept d = em.find(Dept.class, deptno);
			em.remove(d);
			tx.commit();
		} catch (Exception e) {
			System.out.println("Exception  = " + e);
			tx.rollback();
		} finally {
			em.close();
		}
	}
	public void update(Dept modified) {
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			Dept d= em.find(Dept.class, modified.getDeptno());
			d.setDname(modified.getDname());
			d.setLoc(modified.getLoc());
			tx.commit();
		} catch (Exception e) {
			System.out.println("Exception  = " + e);
			tx.rollback();
		} finally {
			em.close();
		}
	}
	public void create(Dept d) {
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			em.persist(d);
			tx.commit();
		} catch (Exception e) {
			System.out.println("Exception  = " + e);
			tx.rollback();
		} finally {
			em.close();
		}
	}

	public static void main(String[] args) {
		DeptManager mgr = new DeptManager();
	for(int i = 10; i < 100;i+=10)
	{
		Dept d = new Dept();
		d.setDeptno(i);
		d.setDname("HR" + i);
		d.setLoc("Pune");
		mgr.create(d);
	}
	
		mgr.delete(20);
		Dept dept = new Dept();
		dept.setDeptno(100); dept.setDname("ITraining"); dept.setLoc("Hyd");		
		mgr.update(dept);
		mgr.list();
		emf.close();
	}

	
}
