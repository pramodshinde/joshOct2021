package demo;

public class Demo {
	public Demo() {
		System.out.println("Demo Constructor");
	}
}
