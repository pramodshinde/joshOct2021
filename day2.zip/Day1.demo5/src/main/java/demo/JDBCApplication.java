package demo;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages = "demo")
public class JDBCApplication {
@Bean
public DataSource ds() {
	DriverManagerDataSource ds = new DriverManagerDataSource();
	ds.setDriverClassName("org.hsqldb.jdbc.JDBCDriver");
	ds.setUrl("jdbc:hsqldb:hsql://localhost/");
	ds.setUsername("SA");
	ds.setPassword(null);
	return ds;
}
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JDBCApplication.class);
		
		DeptDAO dao = ctx.getBean("deptdao", DeptDAO.class);
		for (int i = 10;i<100;i+=10) {
			Dept d= new Dept(i,"DNameof"+i,"Pnq");
			if ((i%20)==0)
				d.setLoc("Hyt");
			dao.insert(d);
		}
		System.out.println("--------------List -----------------");
		dao.read().forEach(System.out::println);
		
		dao.delete(20);
		dao.update(10,"HR", "Del");
		System.out.println("--------------Modified List -----------------");
		dao.read().forEach(System.out::println);
		
	}

}
