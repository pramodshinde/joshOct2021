package demo;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component(value = "deptdao")
public class DeptDAO {
	@Autowired
	private DataSource ds;
	private JdbcTemplate template;
	
	@PostConstruct
	public void initmethod() {
		template = new JdbcTemplate(ds);
	}
	public void insert(Dept d) {
		// create table dept  (deptno  integer  primary key, dname varchar(20), loc varchar(20))
		String sql  = "insert into dept values (" + d.getDeptno() + ", '" + d.getDname() + "','" + d.getLoc() + "')";
		System.out.println("in insert of DeptDAO with " + sql);
		template.execute(sql);
	 
	}
	
	public List<Dept> read() {
		String sql = "select * from dept";
		System.out.println("in read of DeptDAO with " + sql);
		List<Dept> departmentList = template.query(sql, new BeanPropertyRowMapper(Dept.class));
		return departmentList;
	}

	public void update(int deptno, String newdname, String newloc) {
		String sql = "UPDATE dept SET dname='" + newdname + "', loc='" + newloc + "' WHERE deptno=" + deptno;
		System.out.println("in update of DeptDAO with " + sql);
		template.execute(sql);
	}

	public void delete(int deptno) {
	
		String sql = "DELETE FROM dept WHERE deptno=" + deptno;
		System.out.println("in delete of DeptDAO with " + sql);
		template.execute(sql);
	}
}
