package demo1;

import org.springframework.stereotype.Component;

@Component(value = "ora")
public class OracleConnection implements Connection{

	public OracleConnection() {
		System.out.println("OracleConnection Constructor");
	}
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Open method of Oracleconnection invoked ");
	}

	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Close method of Oracleconnection invoked ");
	}

}
