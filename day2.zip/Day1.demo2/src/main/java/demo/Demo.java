package demo;

import org.springframework.stereotype.Component;

@Component
public class Demo {
	public Demo() {
		System.out.println("Demo Constructor");
	}
}
