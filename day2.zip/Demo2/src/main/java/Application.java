import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import demo.Simple;
import demo1.Connection;
import demo1.DeptDAO;
import demo1.OracleConnection;

@Configuration // xml file
@ComponentScan(basePackages = "demo, demo1")
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new AnnotationConfigApplicationContext(Application.class);
		System.out.println("----------------Context Loaded ---------------");
	
	//	OracleConnection con = new OracleConnection();
	// interface to class
	//	Connection con = new OracleConnection();
	//	Connection con = ctx.getBean("ora", Connection.class);
	//	con.open();
	//	con.close();
		
		DeptDAO dao = ctx.getBean("deptdao", DeptDAO.class);
	//	dao.setCon(con);
		dao.save();
		
		
		
		/*
		Simple s1 = ctx.getBean("simple",Simple.class);
		s1.m1();
		Simple s2 = ctx.getBean("simple",Simple.class);
		s2.m1();
		*/
	}

}
