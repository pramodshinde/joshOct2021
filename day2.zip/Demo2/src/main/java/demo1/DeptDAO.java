package demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component(value = "deptdao")
public class DeptDAO {
	@Autowired
	@Qualifier(value = "sql")
	private Connection con ;
	public void save() {
		getCon().open();
		System.out.println("Save of DeptDAO");
		getCon().close();
	
}
	public Connection getCon() {
		return con;
	}
	public void setCon(Connection con) {
		this.con = con;
	}
}
