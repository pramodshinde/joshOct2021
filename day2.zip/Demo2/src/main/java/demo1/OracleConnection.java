package demo1;

import org.springframework.stereotype.Component;

@Component(value = "ora")
public class OracleConnection implements Connection {

	public void open() {
		System.out.println("Open of OracleCOnnection invoked ");
	}

	public void close() {
		System.out.println("Close of OracleCOnnection invoked ");
		
	}

}
