package demo1;

import org.springframework.stereotype.Component;

@Component(value = "sql")
public class SQLConnection implements Connection {

	public void open() {
		System.out.println("Open of SQLConnection invoked ");
	}

	public void close() {
		System.out.println("Close of SQLConnection invoked ");
		
	}

}
