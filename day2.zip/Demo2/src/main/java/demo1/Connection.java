package demo1;

public interface Connection {
	public void open();
	public void close();
	
}
