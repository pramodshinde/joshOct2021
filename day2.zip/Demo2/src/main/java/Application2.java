import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import demo.Emp;
import demo.EmpDAO;
import demo.Simple;
import demo1.Connection;
import demo1.DeptDAO;
import demo1.OracleConnection;

@Configuration // xml file
@ComponentScan(basePackages = "demo")
public class Application2 {
	@Bean(value = "dao")
	public EmpDAO empdao() {
		System.out.println("Application2 configuration method empdao invoked ...");
		return new EmpDAO("Vaishali");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new AnnotationConfigApplicationContext(Application2.class);
		System.out.println("----------------Context Loaded ---------------");
		EmpDAO dao = ctx.getBean("dao", EmpDAO.class);
		Emp e = new Emp(10,"AA",111.11);
		dao.save(e);
		
	}

}
