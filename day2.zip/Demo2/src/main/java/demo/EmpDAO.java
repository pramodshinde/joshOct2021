package demo;

import org.springframework.stereotype.Component;

public class EmpDAO {

	public EmpDAO() {
		System.out.println("EmpDAO contructor invoked ..");
	}
	public EmpDAO(String name) {
		System.out.println("EmpDAO contructor with param invoked .." + name);
	}	
	
	public void save(Emp e) {
		System.out.println("Save of EmpDAO " + e);
	}
}
