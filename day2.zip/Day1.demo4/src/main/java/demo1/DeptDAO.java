package demo1;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component(value="deptdao")
public class DeptDAO {
	
 public  DeptDAO (){
	  System.out.println("DeptDAO Constructor ..." + con);
  }
@PostConstruct
 public void m1() {
	 System.out.println("in m1 of Deptdao " + con);
 }
 
	@Autowired()
	@Qualifier(value="sql")
	private Connection con;
	
	public void insert() {
		getCon().open();
		System.out.println("in insert of DeptDAO");
		getCon().close();
	}

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}
}
