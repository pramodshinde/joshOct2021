import java.util.ArrayList;
import java.util.List;

public class Lab4 {
	public static void main(String[] args) {
		List<String> l1 = new ArrayList<>();
		l1.add("aa");
		l1.add("bb");
		l1.add("aa");
		
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0;i < 10;i++) {
			list.add((int)(Math.random()*1000));
		}
		System.out.println(list);
		
	/*	for (Integer intvalue : list) {
			System.out.println("value =" + intvalue);
		}
	*/
		list.forEach(intvalue-> System.out.println("value =" + intvalue));
		
	}
}
