import java.util.Scanner;

public class Lab6 {

	public double divide() throws Exception {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter  Number 1 :");
			int n1 = scanner.nextInt();

			System.out.println("Enter Number 2 :");
			int n2 = scanner.nextInt();

			//System.out.println("Division = " + (n1 / n2));
			return n1/n2;
		} catch (Exception e) {
			System.out.println("Some Exception ....");
			throw new Exception("Problemm.. ");
		}
	//	return 0;
	}
	public static void main(String[] args) {
		Lab6 lab = new Lab6();
	try {
		System.out.println("Output = " + 	lab.divide());
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}

}
