interface Data<T>{
	public void save(T s);
}
class MySql1 implements Data<String>{
	public void save(String s) {
		System.out.println("save into mysql data using string "+ s);
	}
}

class Oracle1 implements Data<Double>{

	@Override
	public void save(Double d) {
		System.out.println("SaveofData using Double " + d);
	}
	
}

public class Lab5 {
	public static void main(String[] args) {
		Data<String> d1 = new MySql1();
		d1.save("sss");
		Data<Double> d2 = new Oracle1();
		d2.save(200.0);
	}
}
