
public class Lab1 {

	public static void main(String[] args) {
		
		String str = "Hello World!!! ";
		System.out.println(str);
		int len = str.length();
		System.out.println("Length of given string is " + len);
		str = str + "a";
		System.out.println(str);
		len = str.length();
		System.out.println("Length of given string is " + len);
		
	}

}
