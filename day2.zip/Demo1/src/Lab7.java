import java.util.ArrayList;
import java.util.List;

public class Lab7 {
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0;i < 10;i++) {
			list.add((int)(Math.random()*1000));
		}
		System.out.println(list);
		
//		list.forEach(intvalue-> System.out.println("value =" + intvalue));
		for (Integer integer : list) {
			if (integer > 400)
				System.out.println(integer);
		}
		System.out.println("---------------");
		list.stream().filter(value-> value> 400).forEach(System.out::println);
		
	}
}
