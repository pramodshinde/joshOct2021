interface DataSupport{
	public void save(String s);
}
class MySql implements DataSupport{
	public void save(String s) {
		System.out.println("save into mysql database");
	}
}
class Oracle implements DataSupport{
	
	public void save(String s) {
		System.out.println("save into oracle database");
	}
	
}

public class Lab2 {
	public static void main(String[] args) {
		// save the data in database
		DataSupport support =null ;
		int i = 12;
		if ( i > 10) {
			support = new MySql();
		}
		else
		{
			support = new Oracle();
		}
		support.save("aa");
		
	}
}
