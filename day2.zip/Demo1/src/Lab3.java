import java.util.ArrayList;
import java.util.List;

public class Lab3 {
	public static void main(String[] args) {
		// List of Objects
    	//	List l1 = new ArrayList<>();

		// list of String
		List<String> l1 = new ArrayList<>();
		l1.add("aa");
		l1.add("bb");
		l1.add("aa");
		System.out.println(l1);
	}
}
