package demo;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Component(value = "deptdao")
@Transactional(propagation = Propagation.REQUIRED)
public class DeptDAO {
	@Autowired
	private SessionFactory sessionfactory;
	private HibernateTemplate template;
	
	@PostConstruct
	public void initmethod() {
		template = new HibernateTemplate(sessionfactory);
	}
	public void insert(Dept d) {
		// create table dept  (deptno  integer  primary key, dname varchar(20), loc varchar(20))
		System.out.println("in insert of DeptDAO with " + d);
		template.save(d);
	}
	
	public List<Dept> read() {
		String sql = "select d from Dept d";
		System.out.println("in read of DeptDAO with " + sql);
		List<Dept> departmentList = template.loadAll(Dept.class);
		return departmentList;
	}

	public void update(Dept d) {
		System.out.println("in update of DeptDAO with " + d);
		template.update(d);
	}

	public void delete(int deptno) {
		System.out.println("in delete of DeptDAO with " + deptno);
		Dept d = template.get(Dept.class, deptno);
		template.delete(d);
	}
}
