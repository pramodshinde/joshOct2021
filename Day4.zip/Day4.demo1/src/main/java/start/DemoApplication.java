package start;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import dao.EmpDAO;
import entities.Emp;

@SpringBootApplication
@ComponentScan(basePackages = "dao,config")
public class DemoApplication {

  public static void main(String[] args) {
   ApplicationContext ctx =  SpringApplication.run(DemoApplication.class, args);
   EmpDAO dao = ctx.getBean(EmpDAO.class);
   for (int i = 1; i < 10; i++) {
	   Emp e = new Emp(i, "Nameof"+i, i*100.1);
	   dao.insert(e);
   }
   List<Emp > list = dao.list();
   Emp e1 = new Emp(1,"Vaishali",1111.1);
   dao.update(e1);
   
   dao.delete(2);
   list.forEach(System.out::println);
   
  }

}
