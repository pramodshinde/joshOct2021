package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import entities.Emp;
@Repository
public class EmpDAO {

	@Autowired
	private SessionFactory factory;
	
	
	public void delete(int empno) {
		System.out.println("Empdao - delete invoked with " + empno);
		 Session session = factory.openSession();
	        Transaction tx = null;
	        try
	        {
	            tx = session.beginTransaction();
	            Emp e= session.get(Emp.class,empno);
	            session.delete(e);
	            tx.commit();
	        } 
	        catch (HibernateException ex)
	        {
	        	System.out.println("EmpDAO - delete exception " + ex);
	            if(tx != null)
	                tx.rollback();
	        }
	        finally
	        {
	            session.close();
	        }
	}
	
	
	public void update(Emp e) {
		System.out.println("Empdao - update invoked with " + e);
		 Session session = factory.openSession();
	        Transaction tx = null;
	        try
	        {
	            tx = session.beginTransaction();
	          session.update(e);
	            tx.commit();
	        } 
	        catch (HibernateException ex)
	        {
	        	System.out.println("EmpDAO - update exception " + ex);
	            if(tx != null)
	                tx.rollback();
	        }
	        finally
	        {
	            session.close();
	        }
	}
	
	public void insert(Emp e) {
		System.out.println("Empdao - insert invoked with " + e);
		 Session session = factory.openSession();
	        Transaction tx = null;
	        try
	        {
	            tx = session.beginTransaction();
	            session.save(e);
	            tx.commit();
	        } 
	        catch (HibernateException ex)
	        {
	        	System.out.println("EmpDAO - insert exception " + ex);
	            if(tx != null)
	                tx.rollback();
	        }
	        finally
	        {
	            session.close();
	        }
	}
	public List<Emp> list() {
		System.out.println("Empdao - list invoked ");
		 Session session = factory.openSession();
		 List<Emp> list = null;
 	        try
	        {
	         list =   session.createQuery("select e from Emp e").list();
	        } 
	        catch (HibernateException ex)
	        {
	        	System.out.println("EmpDAO - list exception " + ex);
	        }
	        finally
	        {
	            session.close();
	        }
 	        return list;
	}

}
