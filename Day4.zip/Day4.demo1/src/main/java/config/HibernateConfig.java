package config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
@Configuration
public class HibernateConfig {

	// database
	public DataSource ds() {
/*		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.jdbc.Driver");
		ds.setUrl("jdbc:mysql://mydb.chidkemxak9r.us-east-1.rds.amazonaws.com:3306/tmp");
		ds.setUsername("admin");
		ds.setPassword("mypassword");
		return ds;
	*/
		
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("org.hsqldb.jdbc.JDBCDriver");
		ds.setUrl("jdbc:hsqldb:hsql://localhost/");
		ds.setUsername("sa");
		ds.setPassword("");
		return ds;
	}
	
	
	@Bean
	public LocalSessionFactoryBean sessionfactory() {
		LocalSessionFactoryBean bean = new LocalSessionFactoryBean();
		bean.setDataSource(ds());
		bean.setPackagesToScan("entities");
		bean.setHibernateProperties(hibernateProperties());
		return bean;
	}

	private final Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "create-drop");
		hibernateProperties.setProperty("hibernate.show_sql", "true");
		
		hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		return hibernateProperties;
	}

	
	
}
